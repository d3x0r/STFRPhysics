# The Homogeneous Propagation Framework: Philosophical Foundations and Postulate Structure

**James Buckeyne**  
Independent Research  
Fernandina Beach, FL 32034; United States  
Email: d3ck0r@gmail.com  
ORCID iD: 0009-0004-2865-6447  

*Companion to the homogeneous propagation framework paper series.*

## Abstract

The homogeneous propagation framework recovers the standard kinematic and gravitational structures of modern physics from a propagation-first starting point. The technical papers develop the mathematics; this companion addresses the conceptual and philosophical content that those papers leave implicit. Three themes are developed. First, the framework's postulate structure is not static: later papers consume the assumptions of earlier ones, so that the set of irreducible presuppositions shrinks as the framework matures. This progression is traced explicitly. Second, the emergent status of Lorentz invariance — why instruments made of a single-speed medium cannot detect their own motion through it — is developed as a sustained narrative rather than a single-paragraph remark. Third, the framework's positions on several contested questions in the philosophy of physics — the existence of a preferred frame, the nature of time, the ontological status of spacetime geometry, and the explanatory direction from substrate to symmetry — are stated plainly rather than left scattered across technical derivations. These positions are organized into two tiers: the ontological commitments the framework makes about what exists, and the consequences that follow from those commitments, including a no-invisible-hands corollary requiring that every apparent action at a distance reduce to a local imbalance in the mediating medium.

## 1. Introduction

The homogeneous propagation framework is developed across a series of companion papers, each addressing a specific technical domain: flat-vacuum kinematics, transport and local geometry, noncollinear composition, displacement dynamics, weak-field observational tests, and excitation closure. Each paper is intended to be self-contained at the level of its own derivations. What none of them does individually is state, in one place, the philosophical commitments that hold the series together.

That omission is partly deliberate. The technical results are meant to stand on their own formal merits, independent of any particular philosophical reading. But the framework does carry a distinctive worldview — about what exists, about what is derived versus assumed, about what the familiar relativistic structures are and where they come from — and leaving that worldview entirely implicit risks both misunderstanding and missed connections.

This companion is therefore not a summary of the technical results. It is an account of what the framework claims the world is like, how those claims differ from the standard alternatives, and what remains genuinely open.

A note on the status of what follows. This companion is best read as a request for comments rather than as a settled doctrine. It states a particular philosophical view of what the framework is and what it commits its readers to, but it does so in awareness that other interpretations of the same formal apparatus are possible. The math of the technical papers can be read under several metaphysical interpretations — substantivalist or relationalist, block-universe or presentist, dimension-of-time or parameter-of-change — and the calculations will return the same numerical results under any of them. What the companion offers is the reading under which the framework speaks in its own voice: the interpretation that explains why the vocabulary is what it is, why the postulate structure shrinks the way it does, and why the recovered relativistic structures are read as emergent rather than primitive.

The distinction between ontological and epistemic commitments is preserved throughout. What the framework predicts, what experiments it underwrites, what calculations it supports — these are the epistemic content, and they do not depend on the metaphysical reading. What the framework says the world is like — what exists, what is derived, what is parametric — this is the ontological content, and it is what the present companion develops. Adopting the framework's formulas does not require adopting the framework's metaphysics. Understanding the framework as it presents itself does.

The author's own view is that the interpretation developed here is not merely one option among many but the reading that best fits the model the math describes. That view should be flagged as author bias: it is what the person who built the framework would naturally think about how to read the framework, and a reader is entitled to discount it accordingly. The companion is offered in the spirit of staking out a position clearly enough that it can be argued with, rather than hedging it into invisibility. If a more economical or more accurate interpretation of the same formal apparatus exists, the framework is better served by hearing about it than by the present author insisting otherwise.

With that framing in place, the remainder of the companion proceeds as follows. Section 2 states the present closure status of the framework — what is already derived, what remains foundational, and what sits at the frontier. Section 3 traces how the framework's own postulate structure has shrunk as the series has developed, with later papers absorbing the assumptions of earlier ones. Sections 4 and 5 then take up the substantive ontological content: the emergent status of Lorentz invariance, and the framework's specific commitments about what exists and what follows from those commitments. Section 6 names what remains genuinely open.


## 2. Present Closure Status

The framework is best read, at its present stage, as a staged derivational program rather than as a single fully compressed field theory. Its current status is therefore easiest to state by distinguishing four kinds of elements: foundational commitments, derived structure, interpretive decompositions, and frontier structure.

First, some elements remain **foundational** at the present stage. These include the existence of a propagation-supporting vacuum medium with definite storage properties, the possibility of sustained localized closure, and the displacement sourcing relation used in the gravitational branch. These are not yet all reduced to one deeper generating law.

Second, substantial parts of the framework are already **derived within the present scope**. These include the homogeneous kinematic structure recovered from propagation, the transport/local-geometry hierarchy, the weak-field displacement geometry, and the corresponding weak-field observational recoveries. In these sectors the framework is not merely suggestive; it already carries explicit formal structure and concrete observational overlap.

Third, some quantities appearing in the papers are **interpretive rather than additional hypotheses**. They organize or partition already-recovered structure, but do not introduce independent free physics. They should therefore not be read as separate knobs or postulates merely because they are named separately.

Fourth, some parts of the framework remain at the **frontier** of the program. This is especially true where excitation closure, constitutive response, and the deeper reduction of displacement sourcing are concerned. In those sectors the present papers should be read as formalization and stabilization steps rather than as final substrate closure.

The correct global reading is therefore neither that the framework is already a fully unified final theory, nor that it is an unstructured collection of speculative pieces. It is a program in which some sectors are already comparatively tight, while the deeper reductions that would compress them into a single generating formalism remain frontier work.

## 3. The postulate ladder

### 3.1 The starting postulates

The first paper in the series, the homogeneous light propagation framework, begins from two assumptions.

The first is a propagation postulate: light propagates through connection space at a definite baseline speed $c$, with sources and observers free to move relative to that propagation layer during the interval between emission and reception. This is stated as a native propagation condition,

$$\|\vec{x}_o(t_o) - \vec{x}_s(t_e)\| = c\,(t_o - t_e),$$

relating the positions of source and observer at their respective event times through the single parameter $c$. The condition is implicit: the travel time to be solved for also enters the geometry that defines the path.

The second is a material postulate, weaker and less foregrounded: that stable material structure — rods, clocks, and the systems built from them — is sustained by repeated two-way photonic interactions carried through the same propagation layer. A rod's length is not an independent given; it is the extent that can be maintained by the interaction structure that holds the rod together. A clock's rate is not an independent given; it is the cycling frequency supported by that same interaction cost.

From these two assumptions, the propagation paper recovers the standard contraction factor $\lambda(v) = \sqrt{1 - v^2/c^2}$, the timing factor $\gamma(v) = 1/\sqrt{1 - v^2/c^2}$, the one-dimensional Lorentz transformation in form, the simultaneity slope $vx/c^2$, the source-side Doppler factor, and the scalar aberration relation. These are not assumed; they are found as consequences of the propagation geometry and the material postulate together.

### 3.2 The substrate absorbs the first postulate

The vacuum LC companion supplies a physical substrate for the propagation postulate. The vacuum is characterized by two complementary storage properties: permittivity $\varepsilon_0$ (electric storage capacity per unit length, in F/m) and permeability $\mu_0$ (magnetic storage capacity per unit length, in H/m). Their product gives $\varepsilon_0 \mu_0 = \text{s}^2/\text{m}^2 = 1/c^2$, so that $c = 1/\sqrt{\varepsilon_0 \mu_0}$ is the wave speed of the medium — the rate at which the front of LC cycling advances through space. This is not a coincidence that the constants "happen" to combine to give $c$. It is a direct statement that $c$ is the propagation speed of a medium with those storage densities, exactly as the speed of sound follows from the elastic modulus and density of air.

Once the substrate is in place, the first postulate is no longer a postulate. Light propagates at $c$ because the medium supports exactly one propagation speed, set by its own storage densities. There is no other speed available to it. The propagation condition becomes a consequence rather than an assumption.

### 3.3 The excitation layer absorbs the second postulate

The second postulate — that material structure is sustained by two-way interactions through the medium — is initially stated as an external constraint on what matter must do. But if matter is itself a sustained excitation of the same LC medium, then that constraint is not external. It is a tautology.

An LC excitation cycling between the capacitive and inductive storage modes of the vacuum is, by construction, subject to the medium's propagation speed. Its spatial extent is set by the cycling, its timing is set by the cycling, and its internal coherence is maintained by the cycling. The "two-way interaction cost" that produces contraction and time dilation is not something imposed on matter from outside; it is the cost of being what matter is — a structure made of medium, propagating through medium.

The excitation dynamics paper develops this further by placing a minimal excitation field on the displaced background and showing that closure, support selection, and environmental response follow from the transport/storage logic of the medium. But the key philosophical point is already available at the LC companion stage: if matter is medium, the material postulate is not a postulate. It is a consequence of the ontology.

### 3.4 The displacement postulate

The displacement dynamics paper introduces genuinely new content: mass-energy sources a displacement of the transport-supporting structure, and changes in that displacement propagate causally at $c$. This is the gravitational postulate. It is not derivable from the flat-vacuum LC picture alone; it adds a claim about what mass does to the medium beyond merely existing within it.

From this postulate, the paper recovers the static equilibrium geometry $D(r,d)$, the cumulative displacement field $\Sigma(r)$, the Newtonian limit, perihelion precession, Shapiro delay, light deflection, gravitational waves, and (with the vector extension) frame-drag effects. These are derived, not fitted.

### 3.5 Does the displacement postulate also get consumed?

The excitation dynamics paper begins to address this. If a localized excitation occupies vacuum storage — if it loads the capacitive and inductive modes of the medium at a specific location — then it must affect the transport structure by its presence. The excitation is not a passive rider on an unperturbed background. It is a region where the storage capacity is actively engaged, and that engagement changes the effective geometry that other excitations see.

The question is whether the specific form of the displacement — the $D(r,d)$ geometry, the sourcing relation $\Sigma = GM/(c^2 r)$, and the causal propagation at $c$ — can be derived from the excitation's storage-loading properties rather than postulated independently. The excitation paper now gives that downstream program a more explicit formal shape through a closure functional, support law, and occupancy channel. What remains is not the existence of that branch, but the deeper reduction of the sourcing relation itself. In that sense this is best read as the deepest remaining reduction step in the framework's postulate structure, rather than as an absence of formal architecture.

### 3.6 What remains

If the displacement postulate is eventually derived from the excitation structure, the framework's irreducible presuppositions reduce to something like:

1. **A continuous medium exists** with two complementary storage modes whose densities are $\varepsilon_0$ and $\mu_0$.
2. **The medium supports closure**: sustained localized excitations are possible, not just dispersing waves.
3. **The medium's behavior is mathematically describable**: continuous field equations, phase constraints, and variational principles apply.

The first is an ontological commitment — the vacuum is a thing with properties. The second is a structural commitment — the thing admits standing modes. The third is an epistemological commitment — the structure is lawful and expressible in mathematics.

These are deeper and fewer than the starting postulates of the propagation paper, and they are of a different character than the postulates of standard physics. They do not say "the speed of light is the same in all frames" or "the laws of physics are Lorentz invariant" or "matter curves spacetime." They say: there is a medium, it supports structure, and the structure is lawful. Everything else is supposed to follow.


## 4. Emergent Lorentz invariance

### 4.1 The standard story and its alternative

In special relativity, Lorentz invariance is a postulate about the symmetry of physical law. The laws of physics take the same form in all inertial frames. The speed of light is the same for all inertial observers. These are taken as primitive facts about the structure of spacetime, and the Lorentz transformation is the mathematical expression of that symmetry.

The present framework tells a different story. Lorentz invariance is not a property of spacetime. It is the self-consistent measurement structure of instruments made from a single-speed medium.

The difference is not observational — the two stories make identical predictions for all experiments accessible to medium-constituted observers. The difference is explanatory. It concerns what Lorentz invariance *is*, not what it *predicts*.

### 4.2 The rod

Consider the simplest possible material object: a rod. In this framework, a rod is a sustained electromagnetic structure — an LC excitation pattern that maintains a definite spatial extent through repeated internal interactions carried at speed $c$ through the vacuum medium.

When the rod is at rest in the medium, the two-way interaction cost — the time for a signal to traverse the rod's length and return — is the same in every direction. The rod's internal interaction structure is isotropic.

When the rod moves at velocity $v$ through the medium, the interaction cost becomes direction-dependent. Along the direction of motion, a signal chasing the leading end of the rod takes longer to arrive than a signal heading back toward the trailing end. The round-trip time along the direction of motion is $\tau_\parallel = 2Lc/(c^2 - v^2)$. Transverse to the motion, the round-trip time is $\tau_\perp = 2L/\sqrt{c^2 - v^2}$. These are not equal: longitudinal interactions cost more than transverse ones.

A rod that maintained its rest-frame dimensions while moving would therefore have an internal inconsistency: its longitudinal interaction structure would not match its transverse interaction structure. The rod could not maintain a coherent material configuration.

What happens instead is that the rod's longitudinal extent adjusts until the two-way costs match. The adjustment factor is $\lambda(v) = \sqrt{1 - v^2/c^2}$. The rod contracts. Not because a force compresses it, but because its own internal interaction structure — the same LC cycling that constitutes it — can only close self-consistently at the reduced length.

This is not an optional interpretation. The rod *is* LC cycling. Its length *is* the extent that cycling can span. When the cycling budget is partially consumed by bulk motion, the spanned extent decreases. Contraction is what the rod's own physics requires.

### 4.3 The clock

A clock is an LC oscillation with a definite cycling frequency. At rest, the frequency is set by the medium's storage properties and the excitation's closure scale: $f_0 = mc^2/h$ for a particle of mass $m$, or more generally, $f \sim c/\ell$ for a resonance of spatial extent $\ell$.

When the clock moves at velocity $v$, the total two-way interaction cost per cycle increases. Even after the longitudinal extent has contracted to restore directional consistency, the normalized round-trip time exceeds the stationary value by the factor $\gamma(v) = 1/\sqrt{1 - v^2/c^2}$. The clock ticks slower.

Again, this is not optional. The clock *is* LC cycling. Its period *is* the time for one complete cycle through the medium's storage modes. When the cycling structure moves through the medium, each cycle costs more propagation budget, and the period lengthens. Time dilation is what the clock's own physics requires.

### 4.4 The turntable: how clock offsets build mechanically

Before discussing a distributed clock field, it is worth seeing how the simultaneity offset arises from ordinary time dilation alone, without any synchronization procedure at all.

Place two clocks on a turntable, diametrically opposed, with the turntable oriented so that the diameter is initially perpendicular to the frame's velocity $\vec{v}$. The turntable is at rest in a frame that is itself moving at $v$ through the medium. Now spin the turntable slowly.

As the turntable rotates, one clock sweeps toward the leading edge of the frame and the other sweeps toward the trailing edge. The clock moving to the leading edge now has a higher total speed through the medium — the frame velocity $v$ plus the turntable's tangential contribution in the forward direction. A higher total speed means a larger two-way interaction cost, which means the clock ticks slower. Its accumulated time reading falls behind: it drifts into the future relative to frame center.

Meanwhile, the other clock moves to the trailing edge. Its tangential motion partially opposes the frame velocity, so its total speed through the medium is lower. Lower total speed means less interaction cost, the clock ticks faster, and its accumulated reading advances: it drifts into the past relative to frame center.

After a quarter turn, the two clocks sit on the leading and trailing edges of the frame. The leading clock is behind (delayed); the trailing clock is ahead (advanced). The offset between them is exactly the simultaneity slope $vL/c^2$, where $L$ is the diameter. No synchronization signals were exchanged. No convention was chosen. The offset was built mechanically by the differential time dilation experienced during the rotation — by the plain fact that the two clocks spent time at different speeds through the medium.

This is the key insight: the simultaneity structure is not primarily a synchronization artifact. It is a mechanical consequence of differential interaction cost across the frame. Synchronization procedures (light-signal exchange, slow-clock transport) merely *confirm* an offset that the medium's physics has already built into the clock readings through ordinary time dilation.

### 4.5 Scaling the turntable to a clock field

The turntable model uses two diametrically opposed clocks at macroscopic separation. But the mechanism does not depend on that scale. Move the two clocks closer together along the arc and the absolute offset between them shrinks in proportion to the reduced separation, but the offset *per unit length* remains the same: $v/c^2$ per meter of separation projected onto the velocity direction. Each clock on the arc always has a slightly different local speed through the medium, and the accumulated differences remain appropriate for whatever distance separates them.

In the limit, replace the two discrete clocks with a continuous field of clocks distributed throughout the frame. Each clock sits at a slightly different position, has a slightly different total speed through the medium (due to its position's projection onto $\vec{v}$), and therefore accumulates a slightly different reading. The result is a smooth, position-dependent offset field: the simultaneity slope $-vx/c^2$.

This is the same result that you get by moving clocks outward from a central detector — which is just the turntable picture unrolled. A clock moved slowly from the center to position $x$ along the velocity direction spends time at a slightly higher speed through the medium (if moved forward) or slightly lower speed (if moved backward), and the accumulated differential dilation over the transport path produces the same offset.

### 4.6 Synchronization confirms what the medium already built

With the mechanical origin of the offset in view, the role of synchronization can be stated more precisely. When two clocks at separation $L$ exchange light signals to check their synchronization, the signals travel at $c$ in the medium. The forward signal (trailing clock to leading clock) chases the leading clock and takes longer; the return signal meets the trailing clock and takes less time. The two clocks split the round-trip time and conclude that they are synchronized — that is, that they agree on which event at one location is simultaneous with which event at the other.

But the split is wrong, from the coordinate-frame perspective. The forward leg took longer than the backward leg. The clocks have absorbed the one-way asymmetry into their synchronization and do not notice it. The resulting clock readings carry the offset $vL/c^2$ — the same offset that was already built by the differential dilation of the turntable.

This means that the synchronization procedure is not what *creates* the offset. It is what makes the offset *self-consistent and invisible from within the frame*. The medium's physics builds the offset through differential interaction cost; the synchronization procedure, itself mediated by the same medium, ratifies that offset as "synchronized."

The deeper point is that even without any explicit synchronization at all, the bias is present. Every physical process within the frame — every field configuration, every interaction, every propagation event — takes place in a medium where the one-way propagation cost is direction-dependent. A clock that has never been synchronized with anything still ticks at a rate set by its local speed through the medium, and its accumulated reading reflects its entire history of differential interaction cost. The simultaneity structure is woven into the frame's physics, not layered on top by a convention.

The early propagation-framework paper demonstrated this directly: the light-speed measurement recovers $c$ using unsynchronized clocks, because the correction bias between their unsynchronized readings is the same bias that the medium imposes on the measurement signals. Synchronization gives the observer a language for talking about specific instants, but the underlying directional cost structure persists whether or not anyone has performed a synchronization protocol.

### 4.7 Rotation and transport of the clock field

The turntable model also shows why the clock field remains self-consistent under rotation. When the entire frame (with its distributed clock field) rotates to a new orientation while maintaining the same velocity, the offsets rearrange mechanically.

Return to the two diametrically opposed clocks. Initially they sit perpendicular to $\vec{v}$ and carry no offset relative to each other (both are equidistant from the velocity axis in the $\vec{v}$ projection). As the frame rotates, one clock sweeps to the leading edge and the other to the trailing edge, accumulating opposite offsets through exactly the same differential-dilation mechanism described above. After a 90° rotation, the clocks that were offset-free now carry the full $\pm vL/(2c^2)$ offsets appropriate for their new positions on the leading and trailing edges.

In the continuous clock field, this rearrangement happens smoothly and everywhere. The offset at each clock position is determined by the dot product $\vec{v} \cdot \vec{x}$ — the projection of that clock's position onto the velocity direction. Rotation changes $\vec{x}$ relative to $\vec{v}$, and the offset follows. Clocks that rotate from the leading edge to a transverse position shed their offset through the same differential dilation (their speed through the medium changes as they move through different orientations relative to $\vec{v}$), and clocks rotating into the leading position acquire it.

The net result is that any orientation of the clock field, at any velocity, produces an internally self-consistent synchronization structure whose offsets are mechanically maintained by the differential interaction cost across the frame. The internal observer sees isotropy in every direction, at every orientation, because the anisotropy of the medium is systematically absorbed by the clock field — not through a one-time synchronization convention, but through the continuous, ongoing physics of how LC excitations tick at different rates depending on their speed through the medium.

### 4.8 The measurement tautology

Combine these three results. An observer in this framework measures length with rods (which are LC excitations that have contracted). Measures time with clocks (which are LC excitations that have dilated). Synchronizes distant clocks with light signals (which are LC cycling fronts in the same medium). Every instrument the observer uses is made of the medium and calibrated by the medium's own propagation speed.

When this observer measures the speed of light, the contracted rod and the dilated clock conspire to return exactly $c$. When this observer compares notes with another observer at a different velocity, the two sets of contracted rods, dilated clocks, and offset synchronization structures map onto each other by exactly the Lorentz transformation. Not because spacetime has Lorentzian symmetry, but because both observers' measurement kits are built from the same medium and subject to the same propagation cost.

This is the measurement tautology: the measuring instruments are made of the thing being measured, calibrated by the thing being measured, and checked by the thing being measured. Of course they return invariant results. The invariance is real — no experiment internal to the medium can break it — but its origin is constitutive rather than geometric.

### 4.9 An analogy

Consider a fish swimming in a uniform current. The fish measures distances using its own body length, which is hydrodynamically shaped by the current. It measures time using its own heartbeat, which is metabolically driven by fluid flow. It synchronizes with other fish using pressure waves that propagate at the speed of sound in water. Every measurement the fish makes is mediated by the same fluid that carries the current.

If the fish tries to measure the current, it gets zero — because its ruler has already been deformed by the current, its clock has already been adjusted by the current, and its signals already travel relative to the current. The current is operationally undetectable from inside the fluid, not because it doesn't exist, but because the measurement apparatus is constituted by the fluid.

The analogy is imperfect in an important way: a fish is not made of water, so in principle a fish could carry a non-hydrodynamic instrument (a sealed vacuum chamber, a gyroscope) that responds differently to the current than the water does. In this framework, there is no such escape. There is no medium other than the vacuum LC medium available to us. Every medium we have access to — air, water, crystal lattices, plasma — is itself an excitation pattern of the vacuum medium. There is no material from which to build an instrument that is not already constituted by the thing it would need to detect. The confinement is total, not approximate.


## 5. Ontological commitments and their consequences

The framework is not ontologically neutral. It takes specific positions on what exists, what those things do, and what follows from that. This section states those positions plainly, organized into two tiers: the commitments the framework makes about the nature of the world, and the consequences that flow from them. The commitments are prior; the consequences inherit their force from the commitments rather than standing independently.

### 5.1 Commitments

Three foundational claims define what the framework asserts exists. Each is an ontological stance — a position on what is real rather than what is merely useful — and each departs from the standard picture in a specific and deliberate way. Together they constitute the substrate from which the consequences in 5.2 then follow.

#### 5.1.1 Neo-Lorentzian realism

The framework is neo-Lorentzian in its ontology. There exists a preferred frame — coordinate space — which carries the vacuum storage field and its associated propagation structure. This frame is not one inertial frame among equals; it is the frame in which the medium's storage properties are homogeneous and isotropic.

The reason this preferred frame is undetectable is not that it doesn't exist, but that every detection instrument is made of the medium and co-deforms with it under motion. The Lorentz transformation is not a symmetry of spacetime but the co-deformation map of medium-constituted instruments. The operational equivalence of inertial frames is exact and complete, but it is a consequence of the instruments rather than a property of the arena.

This position is empirically indistinguishable from Einstein's relativity for all experiments conducted with medium-constituted instruments. The distinction is philosophical: it concerns the explanation of invariance, not its predictions. The framework predicts that Lorentz invariance holds exactly at all scales where the medium can be treated as continuous. It also predicts, as a matter of principle, that if the medium has discrete or structured microphysics at some scale, the continuum approximation could fail there, and Lorentz invariance with it. Whether that scale is physically accessible is a separate question.

#### 5.1.2 Presentism and the global now

The framework includes a coordinate-space reference clock that ticks at a constant rate, faster than any physical clock. All physical clocks tick slower because they are LC excitations whose cycling cost is at least as large as the rest-frame cost, and any motion through the medium adds to it.

This structure supports a form of presentism. The universe exists as a spatial manifold of states at each coordinate-time moment. Events that are spatially separated yet share the same coordinate-time value are, in this reading, genuinely simultaneous: they belong to the same global state of the manifold. The relativity of simultaneity is therefore not taken as an ontological fact about time itself, but as an observational consequence of motion-dependent clock-field offsets within the medium.

This is a strong claim, and it should not be understated. Standard special relativity treats the relativity of simultaneity as a discovery about the nature of time itself — there is no objective "now" that extends across space. The block universe follows: past, present, and future all exist equally, and the distinction between them is observer-dependent. The present framework denies this. It says the distinction between past and future is real, that the global now is a feature of the coordinate-time structure, and that the appearance of relative simultaneity is an artifact of how medium-constituted clocks synchronize.

This is an ontological claim about the framework's underlying time structure, not a claim that coordinate time is directly readable from ordinary physical clocks. Physical clocks are medium-constituted processes and therefore systematically slowed images of the deeper coordinate-time ordering.

#### 5.1.3 Gravity as displacement, not curvature

General relativity identifies gravity with the curvature of spacetime. The present framework identifies gravity with the displacement of the transport-supporting spatial structure. The structural analogy is close: in both cases, one sector describes how sources modify the stage, and another describes how motion proceeds on the modified stage. In Wheeler's summary: matter tells spacetime how to curve, and curved spacetime tells matter how to move. The present framework's version: mass tells space how to displace, and displaced space tells mass how to move.

The key difference is that displacement is a deformation of a pre-existing flat structure, not a curvature of a dynamical manifold. The coordinate grid remains flat; the transport structure is shoved relative to it. The resulting effective geometry is what excitations see when they propagate through the displaced transport, and it reproduces the standard weak-field observational predictions. But the underlying ontology is different: there is a flat background, and gravity is a medium effect upon it.

#### 5.1.4 Time as parameter, not dimension

The commitment to presentism in §5.1.2 raises a deeper question that the present subsection takes up directly. Standard presentism holds that only the present moment is real, while still treating time itself as a kind of thing — a dimension of which only one slice is currently actual. The position developed here is more radical. Time is not a dimension of which any slice is actual or any slice is not. It is a parameter we use to order successive states of a substrate that can change.

The standard formulation says change requires time: in order for a state to differ from itself, there must be a temporal axis along which the differing happens. The present framework reverses the order. The capacity of the substrate to hold one configuration and then a different one is the primitive. "Time" is the name for the parameter that orders those configurations relative to each other. There is no time-dimension waiting to be populated by events; there is only a medium whose state is what it is, and a parametric bookkeeping of how that state has changed.

This position has serious philosophical company. It is structurally Leibnizian: in the Leibniz–Clarke correspondence, Leibniz argued against Newton's absolute time on precisely these grounds, that time is the order of succession of events rather than a container in which events occur. Mach restated the position more starkly: time is an abstraction at which we arrive by means of the changes of things, rather than something by which the changes of things are measured. More recently, Julian Barbour has argued for the elimination of time as a fundamental quantity, with only configurations and their relations remaining. The Heraclitean tradition, with its insistence on perpetual flux as the basic feature of the world, expresses the same intuition in older language: there is no river that stays still long enough to be stepped into twice, and what we call time is the parameter of the flowing.

The framework's commitment to this position, rather than to standard presentism, has technical payoff. The familiar objection to medium-based theories is that they smuggle in absolute time and thereby reintroduce exactly what relativity refuted. The objection misses its target here. The framework does not have absolute time. It has a substrate whose state changes, and a parameter that tracks the changing. There is no temporal dimension to be either absolute or relative, because there is no temporal dimension at all. What exists is the medium and its capacity for change; what we name "time" is parametric ordering, not an additional ontological furniture item.

The presentism of §5.1.2 is downstream of this commitment rather than parallel to it. If time is parametric and only the current state of the medium is actual, then the global now is not a slice of a four-dimensional manifold but the present configuration of the substrate. Past states are not real-but-elsewhere; they are not real, full stop. They are the parametric record of changes that have occurred. Future states are not real-but-not-yet; they are the parametric scaffolding of changes that may occur. Only the present configuration is actual, and "time" is the bookkeeping that lets us speak coherently about what was and what may be.

The relativity of simultaneity, on this reading, is a consequence of how clocks within the medium synchronize — exactly as developed in §4 — rather than a fact about time itself. Events sharing the same parameter value are genuinely simultaneous in the ontology. The clock-field offsets that produce the appearance of relative simultaneity are real measurement effects within the medium, but they do not undermine the underlying simultaneity structure they obscure.

#### 5.1.5 The technical vocabulary tracks the parametric reading

The framework's working terminology reflects the position of §5.1.4 rather than merely accommodating it. The foundational paper distinguishes coordinate duration from realized duration, and the choice of "realized" rather than the more familiar "proper" is part of the same commitment.

Proper time in general relativity is what a clock reads along a worldline in a pre-given spacetime, where the duration is already present in the geometric structure waiting to be measured. Realized duration in the present framework names something different: the duration that has come into being through the transport process itself, as medium-constituted processes unfold against the parametric scaffolding of coordinate duration. The word carries its full sense — what has been *made real*, brought into actuality — rather than functioning as a neutral synonym for what a clock reads.

Coordinate duration is the parametric scaffolding: the bookkeeping parameter against which possible changes can be described. Realized duration is what becomes actual through the medium's own operation. The block-universe reading would treat both as equally and timelessly present in a four-dimensional manifold; the framework's reading does not. Only what has been realized through medium change has come into being; the rest is parametric description.

The same word recurs across the foundational vocabulary in related senses: "local realization," "locally realized measurement structure," "realized geometry." In each case it carries the same load. What is realized is what has come into being through the medium's transport and storage operations. What is parametric is what is described in advance of that realization, in the coordinate scaffolding from which the realization is computed. Keeping the distinction visible at the level of vocabulary is part of why the framework chose this word in the first place.

### 5.2 Consequences

Given the commitments of 5.1, certain positions follow — not as additional assumptions but as things that must be true if the medium is real, local, and the sole substrate of physical phenomena. These consequences do philosophical work in both directions: they entail positive claims about how interactions operate, and they provide rejection criteria for mechanisms that cannot meet the locality requirement.

#### 5.2.1 Symmetries as consequences, not axioms

Standard modern physics tends to begin from symmetries — Lorentz invariance, gauge invariance, diffeomorphism invariance — and derive dynamics from the requirement that the laws respect those symmetries. The present framework reverses that explanatory order. It begins from a substrate with definite properties and asks what measurement structure and dynamical regularities follow for observers and instruments constituted by that substrate.

On this reading, Lorentz symmetry is not a primitive demand placed on the theory in advance. It is an emergent observational structure recovered from the behavior of medium-constituted rods, clocks, and signals. The point is not that symmetry is approximate or dispensable, but that within this framework it is explained rather than postulated.

#### 5.2.2 No invisible hands

Every apparent attraction, force, or action at a distance must reduce to a local imbalance in the mediating medium. There are no invisible hands.

This is not an additional postulate but a corollary of the commitments in 5.1. If the vacuum medium is real and all physical phenomena are what that medium does, then every apparent interaction between separated bodies must trace to something local: a displacement gradient, a storage asymmetry, or a propagation-cost differential. What looks like attraction is always the local response of the medium to an imbalance, not a primitive reach across emptiness.

The corollary does negative work as well as positive. Any proposed mechanism that cannot identify the specific local imbalance being equilibrated has not explained the phenomenon — it has redescribed it. Newton was honest about this gap; he could describe gravity's behavior precisely while acknowledging he had no mechanism for it. The framework closes that gap by construction: the displacement is present, the gradient is local, and the excitation follows the gradient because propagation through a displaced medium is cheaper in one direction than the other. No reach. No pull. No invisible hand.

#### 5.2.3 Same weak-field numbers, different causal assignment

A recurring misunderstanding is that if the framework reproduces the weak-field numerical predictions of general relativity, then it must be merely general relativity in different words. That does not follow. Agreement on the leading weak-field values does not by itself fix the causal assignment within the calculation. The framework matches the standard observables in several places while assigning them to different physical structures.

The cleanest way to state the distinction is to separate three kinds of weak-field observable.

First, some measurements are endpoint clock comparisons. The Pound-Rebka result belongs to this class. Once realized clock rates differ with depth in the displacement field, the observed frequency offset between a lower emitter and a higher receiver is already fixed by the endpoint rate ratio. In that sense the experiment is logically exhausted by the clock-rate structure itself: no additional in-transit mechanism is required to obtain the measured shift.

Second, some measurements are path-integrated propagation costs. The Shapiro delay belongs to this class. Light remains locally at \(c\) in realized meters, but the displaced transport region near a mass contains more storage per coordinate meter, so the signal accumulates extra coordinate travel time along the path. This is not an endpoint clock comparison, even though the result is ultimately read by clocks.

Third, some measurements are integrated effective-geometry results. Mercury perihelion advance and geodetic precession belong to this class. The primary object is the orbit equation on the effective displacement geometry. Interpretive decompositions into retardation, kinematic steering, and geometric terms may be useful for comparison with standard post-Newtonian language, but the framework's main claim is the single integrated geometric result.

These distinctions matter because they prevent different observables from being rhetorically collapsed into one generic statement such as "it is all just time dilation" or "it is all just spacetime curvature." The framework's weak-field agreement with standard tests is not presented as a denial of the measurements or as a semantic relabeling of them. It is presented as a claim that the same observational totals can arise from a different underlying ontology: a transport-supporting medium, realized clocks and rods constituted by that medium, and gravity as displacement of the transport structure rather than curvature of a dynamical manifold.


## 6. What remains open

### 6.1 Closure and excitation support

The remaining question is not whether the framework has a formal excitation branch, but how far that branch can be reduced. A continuous, isotropic LC medium supports propagating waves straightforwardly — that is what electromagnetic radiation is. The harder question is what permits the same medium to support sustained localized excitations that maintain identity, closure, and localization.

The excitation dynamics paper now introduces a closure functional, support law, and occupancy channel that together give this branch a defined formal role. What is still missing is the deeper substrate derivation of why those structures arise and what exact mechanism prevents the excitation from dispersing. The unresolved issue is therefore microscopic reduction, not absence of an excitation-side architecture.

### 6.2 The mass spectrum

Even if closure is given a formal support law, the question of why specific closure scales exist — why the electron, muon, proton, and other particles have the masses they do — remains downstream. The framework's hierarchy of constants ($\varepsilon_0$, $\mu_0$ → $c$, $Z_0$; closure → $h$; displacement → $G$) provides a structural account of how the constants relate, but it does not yet predict their values or the particle spectrum.

### 6.3 Charge and spin

The LC medium has two storage modes, and the framework interprets the electric/magnetic duality as the capacitive/inductive phases of one cycling process. But the quantization of electric charge, the existence of half-integer spin, and the detailed structure of the Standard Model gauge group remain downstream. The R3 spin-group monograph in this series develops the rotation-vector framework that provides some of the mathematical scaffolding, but the physical derivation of charge quantization from the medium's topology remains a future task.

### 6.4 The cosmological question

The framework's account of gravity as displacement rather than curvature has implications for cosmology that are not yet developed. If the coordinate grid is flat and the transport structure is displaced relative to it, the large-scale structure of the universe is constrained differently than in general relativity. The companion notes on cosmology sketch some directions, but a systematic cosmological model within this framework has not been constructed.


## 7. Summary

The homogeneous propagation framework carries a distinctive philosophical position. The vacuum is a real medium with measurable storage properties. Everything else — propagation, kinematics, matter, gravity, quantization — is what that medium does. Lorentz invariance is not a fundamental symmetry of spacetime but the self-consistent measurement structure of instruments constituted by the medium. Time has a global structure that is obscured but not negated by the clock-field offsets of moving observers. Gravity is a displacement of the transport structure, not a curvature of a dynamical manifold. And the framework's own postulate structure is not static: as the theory develops, assumptions that were initially primitive are absorbed into consequences of deeper substrate commitments, so that the irreducible presuppositions progressively shrink toward a minimal ontological core.

What remains is harder than what has been done, but it is not all of one kind. The kinematic and weak-field displacement branches are already developed enough to stand in their present scope. The main downstream reductions now concern excitation closure at the substrate level, the particle spectrum, charge quantization, and cosmology. Those problems are still open, but the framework defines them in specific enough terms — as questions about the vacuum medium's support for localized excitations, its topology, and its large-scale displacement structure — that they are tractable research questions rather than philosophical mysteries.

---

*Companion papers:*

- *Homogeneous Light Propagation Framework* (DOI: 10.5281/zenodo.18997960)
- *The Homogeneous Propagation Framework: Transport, Local Geometry, and Displacement Defects* (DOI: 10.5281/zenodo.19079929)
- *The Homogeneous Propagation Framework: Wigner Rotation from Noncollinear Composition*
- *The Homogeneous Propagation Framework: Displacement Dynamics and Gravitational Structure*
- *The Homogeneous Propagation Framework: Weak-Field Observational Tests*
- *The Homogeneous Propagation Framework: Excitation, Closure, and Material Response*
- *The Vacuum as an LC Medium* (substrate companion)
